print ('__init__mygame')
from  .main import *
